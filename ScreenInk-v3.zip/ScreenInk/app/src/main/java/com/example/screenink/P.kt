package com.example.screenink

import android.content.Context

object P {
    val DI = mapOf(
        "laserSize" to 14, "laserTime" to 900, "laserColor" to 0xFFFF3B30.toInt(), "laserType" to 1,
        "penSize" to 6, "penColor" to 0xFF0A84FF.toInt(), "penLine" to 0, "penType" to 0,
        "brushSize" to 22, "brushColor" to 0xFFBF5AF2.toInt(), "brushLine" to 0, "brushType" to 0,
        "hlSize" to 44, "hlColor" to 0xFFFFD60A.toInt(), "hlAlpha" to 110,
        "eraserSize" to 70, "stampSize" to 110, "autoRelease" to 5
    )
    val DS = mapOf("apiKey" to "", "model" to "gemini-2.5-flash",
        "prompt" to "Identify what is in this image and explain it briefly. If it contains a question or problem, answer or solve it.")
    val RANGE = mapOf("laserSize" to (4..60), "laserTime" to (200..5000), "penSize" to (1..40), "brushSize" to (4..80),
        "hlSize" to (8..100), "hlAlpha" to (30..255), "eraserSize" to (10..150), "stampSize" to (30..300), "autoRelease" to (0..15))
    private fun sp(c: Context) = c.getSharedPreferences("ink", 0)
    fun i(c: Context, k: String): Int = sp(c).getInt(k, DI[k]!!)
    fun s(c: Context, k: String): String = sp(c).getString(k, DS[k]!!) ?: DS[k]!!
    fun put(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}
