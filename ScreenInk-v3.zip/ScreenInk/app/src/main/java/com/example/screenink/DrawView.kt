package com.example.screenink

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

enum class Tool { LASER, PEN, BRUSH, HIGHLIGHTER, ERASER, OVAL, RECT, STAMP }

class DrawView(c: Context) : View(c) {
    var tool = Tool.LASER
    var stamp = "⭐"

    private class Item(var path: Path?, val paint: Paint, val text: String? = null, val x: Float = 0f, val y: Float = 0f) {
        val segs = ArrayList<Float>()
    }
    private class Pt(val x: Float, val y: Float, val t: Long)

    private val items = ArrayList<Item>()
    private val trail = ArrayList<Pt>()
    private var cur: Item? = null
    private var sx = 0f
    private var sy = 0f
    private var lx = 0f
    private var ly = 0f
    private var lw = 0f
    private var lt = 0L
    private var liftT = 0L
    private var down = false
    private var hasPos = false
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun i(k: String) = P.i(context, k)
    private fun al(c: Int, v: Int) = (c and 0xFFFFFF) or (v.coerceIn(0, 255) shl 24)

    private fun stroke(w: Float, col: Int, line: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        color = col; strokeWidth = w
        if (line == 1) pathEffect = DashPathEffect(floatArrayOf(0.1f, maxOf(w * 2.2f, 5f)), 0f)
        if (line == 2) pathEffect = DashPathEffect(floatArrayOf(w * 4f + 6f, w * 3f + 6f), 0f)
    }

    private fun inkKind(): Int = if (tool == Tool.PEN) i("penType") else 0

    private fun inkPaint(): Paint = when (tool) {
        Tool.PEN -> {
            val pt = i("penType")
            if (pt == 0) stroke(i("penSize").toFloat(), i("penColor"), i("penLine"))
            else if (pt == 1) stroke(i("penSize").toFloat(), i("penColor"), 0)
            else Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = i("penColor") }
        }
        Tool.BRUSH -> {
            val w = i("brushSize").toFloat()
            val p = stroke(w, i("brushColor"), i("brushLine"))
            p.alpha = 215
            val bt = i("brushType")
            if (bt == 0) p.maskFilter = BlurMaskFilter(maxOf(w * 0.45f, 2f), BlurMaskFilter.Blur.NORMAL)
            if (bt == 2) { p.strokeCap = Paint.Cap.SQUARE; p.strokeJoin = Paint.Join.BEVEL }
            p
        }
        Tool.HIGHLIGHTER -> stroke(i("hlSize").toFloat(), i("hlColor"), 0).apply { alpha = i("hlAlpha"); strokeCap = Paint.Cap.SQUARE }
        Tool.ERASER -> stroke(i("eraserSize").toFloat(), Color.TRANSPARENT, 0).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        else -> stroke(i("penSize").toFloat(), i("penColor"), i("penLine"))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (tool) {
            Tool.LASER -> laserTouch(e)
            Tool.STAMP -> stampTouch(e)
            Tool.OVAL, Tool.RECT -> shapeTouch(e)
            else -> inkTouch(e)
        }
        return true
    }

    private fun stampTouch(e: MotionEvent) {
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = i("stampSize").toFloat(); textAlign = Paint.Align.CENTER }
        items.add(Item(null, p, stamp, e.x, e.y)); invalidate()
    }

    private fun shapePath(x0: Float, y0: Float, x1: Float, y1: Float): Path {
        val p = Path()
        if (tool == Tool.RECT) p.addRect(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1), Path.Direction.CW)
        else p.addOval(RectF(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1)), Path.Direction.CW)
        return p
    }

    private fun shapeTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y
                val m = Item(shapePath(sx, sy, sx, sy), stroke(i("penSize").toFloat(), i("penColor"), i("penLine")))
                cur = m; items.add(m)
            }
            MotionEvent.ACTION_MOVE -> cur?.path = shapePath(sx, sy, e.x, e.y)
            else -> cur = null
        }
        invalidate()
    }

    private fun newInk(x: Float, y: Float): Item {
        val paint = inkPaint()
        return when (inkKind()) {
            0 -> Item(Path().apply { moveTo(x, y); lineTo(x + 0.1f, y) }, paint)
            1 -> Item(null, paint).also { it.segs.add(x); it.segs.add(y); it.segs.add(x + 0.1f); it.segs.add(y); it.segs.add(i("penSize").toFloat()) }
            else -> Item(Path(), paint)
        }
    }

    private fun extend(m: Item, x: Float, y: Float, t: Long, pr: Float) {
        val kind = inkKind()
        if (kind == 0) {
            m.path?.quadTo(lx, ly, (x + lx) / 2, (y + ly) / 2)
        } else if (kind == 1) {
            val base = i("penSize").toFloat()
            val v = hypot(x - lx, y - ly) / maxOf(1L, t - lt)
            val target = if (pr >= 0f) base * (0.35f + 1.3f * pr) else base * (1.25f - 0.8f * (v / 2.5f).coerceIn(0f, 1f))
            lw += (target - lw) * 0.3f
            m.segs.add(lx); m.segs.add(ly); m.segs.add(x); m.segs.add(y); m.segs.add(lw)
        } else {
            val h = maxOf(3f, i("penSize") * 1.4f) / 2f
            val nx = h * 0.7071f
            val ny = -h * 0.7071f
            val ax = lx + nx; val ay = ly + ny
            val bx = x + nx; val by2 = y + ny
            val cx = x - nx; val cy = y - ny
            val dx = lx - nx; val dy = ly - ny
            val cross = (bx - ax) * (cy - by2) - (by2 - ay) * (cx - bx)
            val p = m.path
            if (p != null) {
                if (cross >= 0f) { p.moveTo(ax, ay); p.lineTo(bx, by2); p.lineTo(cx, cy); p.lineTo(dx, dy) }
                else { p.moveTo(dx, dy); p.lineTo(cx, cy); p.lineTo(bx, by2); p.lineTo(ax, ay) }
                p.close()
            }
        }
        lx = x; ly = y; lt = t
    }

    private fun inkTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val m = newInk(e.x, e.y)
                cur = m; items.add(m)
                lx = e.x; ly = e.y; lt = e.eventTime; lw = i("penSize") * 0.5f
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val m = cur
                if (m != null) {
                    val stylus = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                    for (h in 0..e.historySize) {
                        val hx = if (h < e.historySize) e.getHistoricalX(h) else e.x
                        val hy = if (h < e.historySize) e.getHistoricalY(h) else e.y
                        val ht = if (h < e.historySize) e.getHistoricalEventTime(h) else e.eventTime
                        val pr = if (!stylus) -1f else if (h < e.historySize) e.getHistoricalPressure(h) else e.pressure
                        extend(m, hx, hy, ht, pr)
                    }
                    invalidate()
                }
            }
            else -> cur = null
        }
    }

    private fun laserTouch(e: MotionEvent) {
        val type = i("laserType")
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                trail.clear(); down = true; hasPos = true; lx = e.x; ly = e.y
                if (type != 0) trail.add(Pt(lx, ly, e.eventTime))
            }
            MotionEvent.ACTION_MOVE -> {
                if (type != 0) for (h in 0 until e.historySize) trail.add(Pt(e.getHistoricalX(h), e.getHistoricalY(h), e.getHistoricalEventTime(h)))
                lx = e.x; ly = e.y
                if (type != 0) trail.add(Pt(lx, ly, e.eventTime))
            }
            else -> { down = false; liftT = SystemClock.uptimeMillis() }
        }
        postInvalidateOnAnimation()
    }

    private fun drawItem(cv: Canvas, m: Item) {
        val tx = m.text
        if (tx != null) { cv.drawText(tx, m.x, m.y + m.paint.textSize / 3, m.paint); return }
        val p = m.path
        if (p != null) cv.drawPath(p, m.paint)
        var k = 0
        while (k + 4 < m.segs.size) {
            m.paint.strokeWidth = m.segs[k + 4]
            cv.drawLine(m.segs[k], m.segs[k + 1], m.segs[k + 2], m.segs[k + 3], m.paint)
            k += 5
        }
    }

    private fun drawLaser(cv: Canvas) {
        val t = SystemClock.uptimeMillis()
        val type = i("laserType")
        val fade = i("laserTime").toLong()
        val sz = i("laserSize").toFloat()
        val col = i("laserColor")
        if (type == 1) trail.removeAll { t - it.t > fade }
        else if (type == 2) { if (!down && t - liftT > fade + 450) trail.clear() }
        else trail.clear()
        gp.style = Paint.Style.STROKE; gp.strokeCap = Paint.Cap.ROUND; gp.strokeJoin = Paint.Join.ROUND; gp.shader = null
        if (type == 1) {
            for (k in 1 until trail.size) {
                val a = trail[k - 1]; val b = trail[k]
                val f = (1f - (t - b.t) / fade.toFloat()).coerceIn(0f, 1f)
                gp.color = al(col, (80 * f).toInt()); gp.strokeWidth = sz * 2.2f * f + 2f
                cv.drawLine(a.x, a.y, b.x, b.y, gp)
                gp.color = al(col, (255 * f).toInt()); gp.strokeWidth = sz * 0.9f * f + 1f
                cv.drawLine(a.x, a.y, b.x, b.y, gp)
            }
        } else if (type == 2 && trail.size > 1) {
            val ga = if (down || t - liftT <= fade) 1f else (1f - (t - liftT - fade) / 450f).coerceIn(0f, 1f)
            val path = Path(); path.moveTo(trail[0].x, trail[0].y)
            for (k in 1 until trail.size) path.lineTo(trail[k].x, trail[k].y)
            gp.color = al(col, (80 * ga).toInt()); gp.strokeWidth = sz * 2.2f; cv.drawPath(path, gp)
            gp.color = al(col, (255 * ga).toInt()); gp.strokeWidth = sz * 0.9f; cv.drawPath(path, gp)
        }
        val da = if (down) 1f else (1f - (t - liftT) / 250f).coerceIn(0f, 1f)
        if (hasPos && da > 0f) {
            gp.style = Paint.Style.FILL
            gp.shader = RadialGradient(lx, ly, sz * 3f, intArrayOf(al(col, (150 * da).toInt()), al(col, 0)), null, Shader.TileMode.CLAMP)
            cv.drawCircle(lx, ly, sz * 3f, gp)
            gp.shader = null
            gp.color = al(col, (255 * da).toInt()); cv.drawCircle(lx, ly, sz, gp)
            gp.color = al(0xFFFFFF, (190 * da).toInt()); cv.drawCircle(lx - sz * 0.25f, ly - sz * 0.25f, sz * 0.38f, gp)
        }
        if (down || trail.isNotEmpty() || (hasPos && da > 0f)) postInvalidateOnAnimation()
    }

    override fun onDraw(cv: Canvas) {
        val l = cv.saveLayer(null, null)
        for (m in items) drawItem(cv, m)
        cv.restoreToCount(l)
        drawLaser(cv)
    }

    fun undo() { if (items.isNotEmpty()) { items.removeAt(items.size - 1); invalidate() } }
    fun clearAll() { items.clear(); trail.clear(); invalidate() }
}
