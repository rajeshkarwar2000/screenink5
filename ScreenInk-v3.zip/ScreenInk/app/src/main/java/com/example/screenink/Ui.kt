package com.example.screenink

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class HueBar(c: Context, private val pick: (Int) -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pos = -1f
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(context, 28))
    override fun onDraw(cv: Canvas) {
        val r = height / 2f
        p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }, null, Shader.TileMode.CLAMP)
        cv.drawRoundRect(0f, height * 0.25f, width.toFloat(), height * 0.75f, r, r, p)
        p.shader = null
        if (pos >= 0f) { p.color = Color.WHITE; cv.drawCircle(pos, height / 2f, r * 0.8f, p) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        pos = e.x.coerceIn(0f, width.toFloat())
        pick(Color.HSVToColor(floatArrayOf(pos / width * 360f, 1f, 1f)))
        invalidate(); return true
    }
}

class SpectrumDot(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        p.shader = SweepGradient(cx, cy, IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }, null)
        cv.drawCircle(cx, cy, minOf(cx, cy), p)
        p.shader = null
    }
}

object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun glass(c: Context, r: Int, dark: Boolean): GradientDrawable {
        val cols = if (dark) intArrayOf(0xC0262638.toInt(), 0xA0141420.toInt()) else intArrayOf(0x50FFFFFF, 0x20FFFFFF)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, cols).apply {
            cornerRadius = dp(c, r).toFloat(); setStroke(maxOf(1, dp(c, 1)), 0x66FFFFFF)
        }
    }

    fun pill(c: Context, on: Boolean) = GradientDrawable().apply {
        setColor(if (on) 0xCC0A84FF.toInt() else 0x33FFFFFF); cornerRadius = dp(c, 14).toFloat()
    }

    fun text(c: Context, s: String, sp: Float = 14f, color: Int = Color.WHITE) = TextView(c).apply {
        text = s; textSize = sp; setTextColor(color)
    }

    fun label(c: Context, s: String) = text(c, s, 11f, 0xFFBFC3D6.toInt()).apply { setPadding(dp(c, 2), dp(c, 8), 0, dp(c, 2)) }

    fun vbox(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

    fun slider(c: Context, name: String, key: String, fmt: (Int) -> String = { "$it px" }, onChange: () -> Unit = {}): View {
        val r = P.RANGE[key]!!
        val t = label(c, "")
        val s = SeekBar(c).apply {
            max = 100
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            progressTintList = ColorStateList.valueOf(0xFF0A84FF.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        }
        fun show(v: Int) { t.text = "$name    ${fmt(v)}" }
        val cur = P.i(c, key)
        show(cur); s.progress = (cur - r.first) * 100 / (r.last - r.first)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                if (!u) return
                val v = r.first + p * (r.last - r.first) / 100
                P.put(c, key, v); show(v); onChange()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return vbox(c).apply { addView(t); addView(s) }
    }

    fun colors(c: Context, key: String, onChange: () -> Unit = {}): View {
        val palette = intArrayOf(0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(),
            0xFF0A84FF.toInt(), Color.WHITE, Color.BLACK)
        val dots = ArrayList<View>()
        fun paint() {
            dots.forEachIndexed { i, v ->
                val on = P.i(c, key) == palette[i]
                v.scaleX = if (on) 1.3f else 1f
                v.scaleY = v.scaleX
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(palette[i])
                    setStroke(dp(c, if (on) 2 else 1), if (on) Color.WHITE else 0x66FFFFFF)
                }
            }
        }
        val hue = HueBar(c) { col -> P.put(c, key, col); paint(); onChange() }.apply { visibility = View.GONE }
        val row = GridLayout(c).apply { columnCount = 4 }
        val size = dp(c, 24); val m = dp(c, 4)
        palette.forEachIndexed { i, col ->
            val v = View(c); dots.add(v)
            v.setOnClickListener { P.put(c, key, col); paint(); onChange() }
            row.addView(v, GridLayout.LayoutParams().apply { width = size; height = size; setMargins(m, m, m, m) })
        }
        val spec = SpectrumDot(c)
        spec.setOnClickListener { hue.visibility = if (hue.visibility == View.GONE) View.VISIBLE else View.GONE }
        row.addView(spec, GridLayout.LayoutParams().apply { width = size; height = size; setMargins(m, m, m, m) })
        paint()
        return vbox(c).apply { addView(row); addView(hue) }
    }

    fun chips(c: Context, key: String, labels: List<String>, onChange: () -> Unit = {}): View {
        val row = LinearLayout(c)
        val cells = ArrayList<TextView>()
        fun paint() { cells.forEachIndexed { i, v -> v.background = pill(c, i == P.i(c, key)) } }
        labels.forEachIndexed { i, s ->
            val v = text(c, s, 9f).apply { gravity = Gravity.CENTER; setPadding(0, dp(c, 9), 0, dp(c, 9)) }
            v.setOnClickListener { P.put(c, key, i); paint(); onChange() }
            cells.add(v)
            row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(c, 2), 0, dp(c, 2), 0) })
        }
        paint()
        return row
    }

    fun laser(c: Context, ch: () -> Unit = {}): View = vbox(c).apply {
        addView(slider(c, "Size", "laserSize", { "$it px" }, ch))
        addView(slider(c, "Length", "laserTime", { String.format("%.1f s", it / 1000f) }, ch))
        addView(label(c, "Color")); addView(colors(c, "laserColor", ch))
        addView(label(c, "Laser type")); addView(chips(c, "laserType", listOf("Dot", "Line", "Delay"), ch))
    }

    fun pen(c: Context, ch: () -> Unit = {}): View = vbox(c).apply {
        addView(slider(c, "Size", "penSize", { "$it px" }, ch))
        addView(label(c, "Color")); addView(colors(c, "penColor", ch))
        addView(label(c, "Line type")); addView(chips(c, "penLine", listOf("Solid", "Dotted", "Spaced"), ch))
        addView(label(c, "Pen type")); addView(chips(c, "penType", listOf("Ball", "Natural", "Callig."), ch))
    }

    fun brush(c: Context, ch: () -> Unit = {}): View = vbox(c).apply {
        addView(slider(c, "Size", "brushSize", { "$it px" }, ch))
        addView(label(c, "Color")); addView(colors(c, "brushColor", ch))
        addView(label(c, "Line type")); addView(chips(c, "brushLine", listOf("Solid", "Dotted", "Spaced"), ch))
        addView(label(c, "Brush type")); addView(chips(c, "brushType", listOf("Soft", "Round", "Flat"), ch))
    }

    fun highlighter(c: Context, ch: () -> Unit = {}): View = vbox(c).apply {
        addView(slider(c, "Size", "hlSize", { "$it px" }, ch))
        addView(label(c, "Color")); addView(colors(c, "hlColor", ch))
        addView(slider(c, "Intensity", "hlAlpha", { "${it * 100 / 255}%" }, ch))
    }

    fun eraser(c: Context, ch: () -> Unit = {}): View = vbox(c).apply {
        addView(slider(c, "Size", "eraserSize", { "$it px" }, ch))
    }
}
