package com.example.screenink

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import kotlin.math.sin

class PreviewView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(context, 170))
    override fun onDraw(cv: Canvas) {
        val bw = width.toFloat()
        val bh = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0x55000000; cv.drawRoundRect(0f, 0f, bw, bh, 36f, 36f, p)
        val col = P.i(context, "laserColor")
        val sz = P.i(context, "laserSize").toFloat()
        val n = 24
        fun xx(k: Int): Float {
            return bw * (0.08f + 0.6f * k / n)
        }
        fun yy(k: Int): Float {
            return bh * 0.28f + 20f * sin(k * 0.45f)
        }
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (k in 1..n) {
            val f = k / n.toFloat()
            p.color = (col and 0xFFFFFF) or ((90 * f).toInt() shl 24); p.strokeWidth = sz * 2.2f * f + 2
            cv.drawLine(xx(k - 1), yy(k - 1), xx(k), yy(k), p)
            p.color = (col and 0xFFFFFF) or ((255 * f).toInt() shl 24); p.strokeWidth = sz * 0.9f * f + 1
            cv.drawLine(xx(k - 1), yy(k - 1), xx(k), yy(k), p)
        }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(xx(n), yy(n), sz * 3f, intArrayOf((col and 0xFFFFFF) or (150 shl 24), col and 0xFFFFFF), null, Shader.TileMode.CLAMP)
        cv.drawCircle(xx(n), yy(n), sz * 3f, p)
        p.shader = null
        p.color = col; cv.drawCircle(xx(n), yy(n), sz, p)
        p.color = 0xCCFFFFFF.toInt(); cv.drawCircle(xx(n) - sz * 0.25f, yy(n) - sz * 0.25f, sz * 0.38f, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.color = P.i(context, "penColor"); p.strokeWidth = P.i(context, "penSize").toFloat()
        cv.drawLine(bw * 0.08f, bh * 0.62f, bw * 0.6f, bh * 0.62f, p)
        p.color = (P.i(context, "hlColor") and 0xFFFFFF) or (P.i(context, "hlAlpha") shl 24)
        p.strokeCap = Paint.Cap.SQUARE; p.strokeWidth = P.i(context, "hlSize").toFloat().coerceAtMost(60f)
        cv.drawLine(bw * 0.08f, bh * 0.84f, bw * 0.6f, bh * 0.84f, p)
    }
}

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var preview: View
    private lateinit var status: TextView
    private lateinit var go: TextView
    private fun dp(v: Int) = Ui.dp(this, v)

    private fun card(v: View) {
        val w = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = Ui.glass(this@MainActivity, 22, false)
            setPadding(dp(16), dp(12), dp(16), dp(14))
        }
        w.addView(v)
        box.addView(w, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
    }

    private fun head(t: String) {
        box.addView(Ui.text(this, t, 12f, 0xFFE6E8FF.toInt()).apply { letterSpacing = 0.18f; setPadding(dp(6), dp(18), 0, dp(6)) })
    }

    private fun field(hint: String, key: String): View {
        val e = EditText(this)
        e.setText(P.s(this, key)); e.hint = hint; e.setTextColor(Color.WHITE); e.setHintTextColor(0xFFA0A4C0.toInt()); e.textSize = 14f
        e.doAfterTextChanged { P.put(this, key, it.toString()) }
        return e
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(40)) }
        setContentView(ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1B1038.toInt(), 0xFF3A1C71.toInt(), 0xFFB5316B.toInt()))
            addView(box)
        })
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(dp(76), dp(76)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        names.addView(Ui.text(this, "ScreenInk", 28f).apply { typeface = Typeface.DEFAULT_BOLD })
        names.addView(Ui.text(this, "Draw • Point • Capture • Ask AI", 13f, 0xFFD0D3EA.toInt()))
        top.addView(names)
        box.addView(top)
        status = Ui.text(this, "", 14f, 0xFFD0D3EA.toInt()).apply { setPadding(0, dp(12), 0, dp(6)) }
        box.addView(status)
        go = Ui.text(this, "", 17f).apply {
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7B2FF7.toInt(), 0xFFF107A3.toInt())).apply { cornerRadius = dp(18).toFloat() }
            setOnClickListener {
                if (OverlayService.running) startService(Intent(this@MainActivity, OverlayService::class.java).setAction("STOP"))
                else if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow \"Display over other apps\", then tap Start again", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                postDelayed({ refresh() }, 600)
            }
        }
        box.addView(go, LinearLayout.LayoutParams(-1, dp(56)))

        preview = PreviewView(this)
        val ch = { preview.invalidate() }
        head("LIVE MODE")
        card(Ui.vbox(this).apply {
            addView(Ui.text(this@MainActivity, "The app underneath stays fully usable while the toolbar is on screen. Picking a tool turns drawing on, then it returns to the app by itself.", 12f, 0xFFD0D3EA.toInt()))
            addView(Ui.slider(this@MainActivity, "Return to app after", "autoRelease", { if (it == 0) "Off (stay drawing)" else "$it s" }))
        })
        head("LIVE PREVIEW"); card(preview)
        head("LASER POINTER"); card(Ui.laser(this, ch))
        head("PEN"); card(Ui.pen(this, ch))
        head("BRUSH"); card(Ui.brush(this, ch))
        head("HIGHLIGHTER"); card(Ui.highlighter(this, ch))
        head("ERASER"); card(Ui.eraser(this, ch))
        head("STAMPS AND SHAPES"); card(Ui.slider(this, "Stamp size", "stampSize"))
        head("ASK AI (GEMINI)")
        card(Ui.vbox(this).apply {
            addView(Ui.text(this@MainActivity, "Free key: aistudio.google.com/apikey", 12f, 0xFFD0D3EA.toInt()))
            addView(field("Gemini API key", "apiKey"))
            addView(field("Model", "model"))
            addView(field("Question sent with the circled area", "prompt"))
        })
        head("HOW TO USE")
        card(Ui.text(this, "Tap Start and open any app. The toolbar floats on top and the app underneath stays visible and usable.\n\n" +
            "Tap a tool to open its settings and start drawing. After a few seconds without drawing you are back in the app. " +
            "✍️ turns drawing on, 👆 gives the screen back to the app.\n" +
            "↩️ undo   🗑️ clear   ✂️ screenshot an area   ✨ circle to ask AI   ⚙️ settings   ✖️ close\n" +
            "Tap the round logo to fold the toolbar away; drag it to move the toolbar.", 13f, 0xFFE6E8FF.toInt()))
    }

    private fun refresh() {
        go.text = if (OverlayService.running) "⏹  Stop overlay" else "▶  Start overlay"
        status.text = if (OverlayService.running) "Running. Look for the round logo bubble on your screen." else "Overlay is off."
    }
    override fun onResume() { super.onResume(); refresh() }
}
