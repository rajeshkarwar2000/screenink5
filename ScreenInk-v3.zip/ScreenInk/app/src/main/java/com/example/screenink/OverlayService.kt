package com.example.screenink

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

class OverlayService : Service() {
    companion object { var running = false }

    private class Sec(val tool: Tool, val head: View, val body: View, val chev: TextView)

    private lateinit var wm: WindowManager
    private lateinit var draw: DrawView
    private lateinit var bubbleView: View
    private lateinit var panelView: View
    private lateinit var drawLp: WindowManager.LayoutParams
    private lateinit var modeDraw: TextView
    private lateinit var modeTouch: TextView
    private val secs = ArrayList<Sec>()
    private val shapeCells = ArrayList<Pair<Tool, TextView>>()
    private var panelOpen = true
    private val dm = DisplayMetrics()
    private val handler = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var lastFrame: Bitmap? = null
    private var pending: Pair<Rect, Boolean>? = null
    private var answer: View? = null
    private val FL = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FL, PixelFormat.TRANSLUCENT)
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun cell(s: String, sp: Float = 20f) = TextView(this).apply { text = s; textSize = sp; gravity = Gravity.CENTER; setTextColor(Color.WHITE) }
    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "ink").setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("ScreenInk is active")
            .setContentText("Tap to open settings").setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build()).build()
    }

    private fun fg(withProj: Boolean) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or (if (withProj) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0))
        else startForeground(1, notif())
    }

    override fun onCreate() {
        super.onCreate(); running = true
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ink", "ScreenInk", NotificationManager.IMPORTANCE_LOW))
        fg(false)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        draw = DrawView(this); drawLp = lp(-1, -1); wm.addView(draw, drawLp)
        buildPanel()
    }

    private fun addTool(inner: LinearLayout, icon: String, name: String, t: Tool, content: View) {
        val nm = TextView(this).apply { text = name; textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, 0) }
        val chev = cell("▾", 14f)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(5), dp(8), dp(5)) }
        head.addView(cell(icon, 20f), LinearLayout.LayoutParams(dp(32), dp(32)))
        head.addView(nm, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(chev, LinearLayout.LayoutParams(dp(28), dp(28)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(8)); visibility = View.GONE }
        body.addView(content)
        secs.add(Sec(t, head, body, chev))
        head.setOnClickListener { tapTool(t) }
        inner.addView(head, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        inner.addView(body, LinearLayout.LayoutParams(-1, -2))
    }

    private fun tapTool(t: Tool) {
        val s = secs.first { it.tool == t }
        val reopen = !(draw.tool == t && s.body.visibility == View.VISIBLE)
        selectTool(t)
        for (x in secs) { x.body.visibility = View.GONE; x.chev.text = "▾" }
        if (reopen) { s.body.visibility = View.VISIBLE; s.chev.text = "▴" }
    }

    private fun selectTool(t: Tool) { draw.tool = t; setDrawing(true); refreshSel() }

    private fun refreshSel() {
        for (x in secs) x.head.background = Ui.pill(this, draw.tool == x.tool)
        for ((tool, v) in shapeCells) v.background = Ui.pill(this, draw.tool == tool && (tool != Tool.STAMP || v.text.toString() == draw.stamp))
    }

    private fun buildPanel() {
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)) }

        modeDraw = cell("✍️"); modeTouch = cell("👆")
        val seg = LinearLayout(this).apply { background = Ui.glass(this@OverlayService, 14, false) }
        seg.addView(modeDraw, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        seg.addView(modeTouch, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        modeDraw.setOnClickListener { setDrawing(true) }
        modeTouch.setOnClickListener { setDrawing(false) }
        inner.addView(seg)

        addTool(inner, "🔴", "Laser", Tool.LASER, Ui.laser(this))
        addTool(inner, "✏️", "Pen", Tool.PEN, Ui.pen(this))
        addTool(inner, "🖌️", "Brush", Tool.BRUSH, Ui.brush(this))
        addTool(inner, "🖍️", "Highlighter", Tool.HIGHLIGHTER, Ui.highlighter(this))
        addTool(inner, "🧽", "Eraser", Tool.ERASER, Ui.eraser(this))

        inner.addView(Ui.label(this, "SHAPES"))
        val shapes = listOf(Tool.OVAL to "⭕", Tool.RECT to "⬜", Tool.STAMP to "⭐", Tool.STAMP to "❓", Tool.STAMP to "✅",
            Tool.STAMP to "❌", Tool.STAMP to "🔥", Tool.STAMP to "👍", Tool.STAMP to "❗")
        val g = GridLayout(this).apply { columnCount = 5 }
        for ((tool, sym) in shapes) {
            val v = cell(sym, 20f)
            shapeCells.add(tool to v)
            v.setOnClickListener { if (tool == Tool.STAMP) draw.stamp = sym; selectTool(tool) }
            g.addView(v, GridLayout.LayoutParams().apply { width = dp(40); height = dp(40); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        inner.addView(g)
        inner.addView(Ui.slider(this, "Stamp size", "stampSize"))

        inner.addView(Ui.label(this, "ACTIONS"))
        val row = LinearLayout(this)
        listOf("↩️", "🗑️", "✂️", "✨", "⚙️", "✖️").forEachIndexed { i, s ->
            val v = cell(s, 18f)
            v.background = Ui.pill(this, false)
            v.setOnClickListener {
                when (i) {
                    0 -> draw.undo()
                    1 -> draw.clearAll()
                    2 -> select(false)
                    3 -> select(true)
                    4 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    5 -> stopSelf()
                    else -> {}
                }
            }
            row.addView(v, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        inner.addView(row)

        val panel = MaxScroll(this, (dm.heightPixels * 0.75).toInt()).apply {
            addView(inner); background = Ui.glass(this@OverlayService, 20, true)
        }
        val bubble = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF4A148C.toInt(), 0xFFE53935.toInt())).apply {
                shape = GradientDrawable.OVAL; setStroke(dp(2), 0x88FFFFFF.toInt())
            }
        }
        bubble.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground); scaleType = ImageView.ScaleType.CENTER_CROP })
        panelView = panel; bubbleView = bubble

        val bubbleLp = lp(dp(56), dp(56)).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }
        val panelLp = lp(dp(248), -2).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) + dp(64) }
        if (Build.VERSION.SDK_INT >= 31) {
            @Suppress("DEPRECATION") run { panelLp.flags = panelLp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND }
            panelLp.blurBehindRadius = dp(24)
        }
        wm.addView(panel, panelLp)
        wm.addView(bubble, bubbleLp)

        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = bubbleLp.x; oy = bubbleLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) {
                        bubbleLp.x = ox + (e.rawX - dx).toInt(); bubbleLp.y = oy + (e.rawY - dy).toInt()
                        panelLp.x = bubbleLp.x; panelLp.y = bubbleLp.y + dp(64)
                        wm.updateViewLayout(bubble, bubbleLp); wm.updateViewLayout(panel, panelLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) { panelOpen = !panelOpen; showUi(true) }
            }
            true
        }
        selectTool(Tool.LASER)
    }

    private fun showUi(s: Boolean) {
        bubbleView.visibility = if (s) View.VISIBLE else View.INVISIBLE
        panelView.visibility = if (!s) View.INVISIBLE else if (panelOpen) View.VISIBLE else View.GONE
    }

    private fun setDrawing(on: Boolean) {
        modeDraw.background = Ui.pill(this, on); modeTouch.background = Ui.pill(this, !on)
        drawLp.flags = if (on) drawLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(draw, drawLp)
    }

    private fun select(ai: Boolean) {
        showUi(false)
        val holder = arrayOfNulls<View>(1)
        val sv = SelectView(this, ai) { r ->
            holder[0]?.let { wm.removeView(it) }
            if (r == null) showUi(true) else begin(r, ai)
        }
        holder[0] = sv
        wm.addView(sv, lp(-1, -1))
    }

    private fun begin(r: Rect, ai: Boolean) {
        if (proj != null) { grab(r, ai); return }
        pending = r to ai
        startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "STOP" -> stopSelf()
            "DENIED" -> { pending = null; showUi(true); Toast.makeText(this, "Screen capture permission was declined", Toast.LENGTH_SHORT).show() }
            "PROJ" -> { @Suppress("DEPRECATION") val d = i!!.getParcelableExtra<Intent>("data"); if (d != null) startProj(i.getIntExtra("code", 0), d) }
        }
        return START_NOT_STICKY
    }

    private fun startProj(code: Int, data: Intent) {
        fg(true)
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { vd?.release(); reader?.close(); vd = null; reader = null; proj = null }
        }, handler)
        proj = p
        val w = dm.widthPixels; val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay("ink", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        pending?.let { pd -> handler.postDelayed({ grab(pd.first, pd.second) }, 500) }; pending = null
    }

    private fun grab(r: Rect, ai: Boolean) {
        handler.postDelayed({
            val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                val pl = img.planes[0]
                val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(pl.buffer)
                lastFrame = Bitmap.createBitmap(full, 0, 0, img.width, img.height); img.close()
            }
            showUi(true)
            val f = lastFrame
            if (f == null) { Toast.makeText(this, "Capture failed, try again", Toast.LENGTH_SHORT).show(); return@postDelayed }
            val l = r.left.coerceIn(0, f.width - 2); val t = r.top.coerceIn(0, f.height - 2)
            val crop = Bitmap.createBitmap(f, l, t, minOf(r.width(), f.width - l), minOf(r.height(), f.height - t))
            if (ai) ask(crop) else save(crop)
        }, 400)
    }

    private fun save(b: Bitmap) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ScreenInk_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScreenInk")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) {
            contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Saved to Pictures/ScreenInk", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ask(crop: Bitmap) {
        answer?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply { text = "Thinking…"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(4), dp(8), dp(4), dp(8)) }
        val sc = MaxScroll(this, (dm.heightPixels * 0.4).toInt()).apply { addView(tv) }
        val thumb = ImageView(this).apply { setImageBitmap(crop); adjustViewBounds = true; maxHeight = dp(160) }
        fun chip(s: String) = TextView(this).apply { text = s; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = Ui.pill(this@OverlayService, false); setPadding(dp(16), dp(10), dp(16), dp(10)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = Ui.glass(this@OverlayService, 20, true); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        val copy = chip("📋 Copy").apply { setOnClickListener { getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ai", tv.text)) } }
        val close = chip("✖ Close").apply { setOnClickListener { runCatching { wm.removeView(box) }; answer = null } }
        bar.addView(copy); bar.addView(close, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        box.addView(TextView(this).apply { text = "✨ Gemini"; textSize = 14f; setTextColor(0xFFBFC3FF.toInt()) })
        box.addView(thumb); box.addView(sc); box.addView(bar)
        wm.addView(box, lp(minOf(dm.widthPixels - dp(32), dp(560)), -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) })
        answer = box
        val key = P.s(this, "apiKey").trim()
        if (key.isEmpty()) { tv.text = "Add your Gemini API key in the ScreenInk app (Ask AI section)."; return }
        val prompt = P.s(this, "prompt"); val model = P.s(this, "model").trim()
        Thread { val res = gemini(crop, prompt, key, model); handler.post { tv.text = res.replace("**", "").replace("\n* ", "\n• ") } }.start()
    }

    private fun gemini(b: Bitmap, prompt: String, key: String, model: String): String {
        return try {
            val s = minOf(1f, 1280f / maxOf(b.width, b.height))
            val sb = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
            val bo = ByteArrayOutputStream(); sb.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            val parts = JSONArray().put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code >= 400) "Error $code: " + runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            else JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Could not get an answer: ${e.message}" }
    }

    override fun onDestroy() {
        running = false
        for (v in listOf<View?>(draw, bubbleView, panelView, answer)) v?.let { runCatching { wm.removeView(it) } }
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
