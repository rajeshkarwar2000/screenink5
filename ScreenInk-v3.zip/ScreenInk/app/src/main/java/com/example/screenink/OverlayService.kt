package com.example.screenink

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

class OverlayService : Service() {
    companion object { var running = false }

    private lateinit var wm: WindowManager
    private lateinit var draw: DrawView
    private lateinit var stripView: View
    private lateinit var stripLp: WindowManager.LayoutParams
    private lateinit var drawLp: WindowManager.LayoutParams
    private lateinit var modeDraw: TextView
    private lateinit var modeTouch: TextView
    private val toolCells = HashMap<Tool, TextView>()
    private val shapeCells = ArrayList<Pair<Tool, TextView>>()
    private var flyout: View? = null
    private var flyoutKey = ""
    private var stripW = 0
    private var armed = false
    private val release = Runnable { setDrawing(false) }
    private val tick: () -> Unit = { scheduleRelease() }
    private val dm = DisplayMetrics()
    private val handler = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var lastFrame: Bitmap? = null
    private var pending: Pair<Rect, Boolean>? = null
    private var answer: View? = null
    private val FL = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FL, PixelFormat.TRANSLUCENT)
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun cell(s: String, sp: Float = 20f) = TextView(this).apply { text = s; textSize = sp; gravity = Gravity.CENTER; setTextColor(Color.WHITE) }
    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "ink").setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("ScreenInk is active")
            .setContentText("Tap to open settings").setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build()).build()
    }

    private fun fg(withProj: Boolean) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or (if (withProj) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0))
        else startForeground(1, notif())
    }

    override fun onCreate() {
        super.onCreate(); running = true
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ink", "ScreenInk", NotificationManager.IMPORTANCE_LOW))
        fg(false)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        draw = DrawView(this)
        draw.onActivity = { active -> if (active) handler.removeCallbacks(release) else scheduleRelease() }
        drawLp = lp(-1, -1)
        drawLp.flags = drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.addView(draw, drawLp)
        buildPanel()
    }

    private fun blur(l: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 31) {
            @Suppress("DEPRECATION") run { l.flags = l.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND }
            l.blurBehindRadius = dp(24)
        }
    }

    private fun buildPanel() {
        stripW = maxOf(dm.widthPixels / 7, dp(60))
        val cols = if (stripW >= dp(100)) 2 else 1
        val pad = dp(6); val mar = dp(2)
        val cs = (stripW - 2 * pad - cols * 2 * mar) / cols

        fun grid(cells: List<View>): GridLayout {
            val g = GridLayout(this).apply { columnCount = cols }
            for (v in cells) g.addView(v, GridLayout.LayoutParams().apply { width = cs; height = cs; setMargins(mar, mar, mar, mar) })
            return g
        }
        fun div(): View = View(this).apply { setBackgroundColor(0x33FFFFFF) }
        fun addDiv(parent: LinearLayout) { parent.addView(div(), LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }) }

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, 0, pad, pad) }

        modeDraw = cell("✍️"); modeTouch = cell("👆")
        modeDraw.setOnClickListener { setDrawing(true) }
        modeTouch.setOnClickListener { setDrawing(false) }
        body.addView(grid(listOf(modeDraw, modeTouch))); addDiv(body)

        val tools = listOf(Tool.LASER to "🔴", Tool.PEN to "✏️", Tool.BRUSH to "🖌️", Tool.HIGHLIGHTER to "🖍️", Tool.ERASER to "🧽")
        val tcells = ArrayList<View>()
        for ((t, sym) in tools) {
            val v = cell(sym); toolCells[t] = v
            v.setOnClickListener { tapTool(t, v) }
            tcells.add(v)
        }
        body.addView(grid(tcells)); addDiv(body)

        val shapes = listOf(Tool.OVAL to "⭕", Tool.RECT to "⬜", Tool.STAMP to "⭐", Tool.STAMP to "❓", Tool.STAMP to "✅",
            Tool.STAMP to "❌", Tool.STAMP to "🔥", Tool.STAMP to "👍", Tool.STAMP to "❗")
        val scells = ArrayList<View>()
        for ((t, sym) in shapes) {
            val v = cell(sym); shapeCells.add(t to v)
            v.setOnClickListener { tapShape(t, sym, v) }
            scells.add(v)
        }
        body.addView(grid(scells)); addDiv(body)

        val acells = ArrayList<View>()
        listOf("↩️", "🗑️", "✂️", "✨", "⚙️", "✖️").forEachIndexed { i, s ->
            val v = cell(s, 18f)
            v.background = Ui.pill(this, false)
            v.setOnClickListener {
                when (i) {
                    0 -> draw.undo()
                    1 -> draw.clearAll()
                    2 -> select(false)
                    3 -> select(true)
                    4 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    5 -> stopSelf()
                    else -> {}
                }
            }
            acells.add(v)
        }
        body.addView(grid(acells))

        val scroll = MaxScroll(this, (dm.heightPixels * 0.8).toInt()).apply { addView(body) }
        val bubble = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF4A148C.toInt(), 0xFFE53935.toInt())).apply {
                shape = GradientDrawable.OVAL; setStroke(dp(2), 0x88FFFFFF.toInt())
            }
        }
        bubble.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground); scaleType = ImageView.ScaleType.CENTER_CROP })
        val strip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = Ui.glass(this@OverlayService, 18, true); setPadding(0, pad, 0, 0) }
        strip.addView(bubble, LinearLayout.LayoutParams(cs, cs).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = pad })
        strip.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        stripView = strip

        stripLp = lp(stripW, -2).apply { gravity = Gravity.TOP or Gravity.START; x = dp(6); y = dp(70) }
        blur(stripLp)
        wm.addView(strip, stripLp)

        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = stripLp.x; oy = stripLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) {
                        closeFlyout()
                        stripLp.x = (ox + (e.rawX - dx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - stripW))
                        stripLp.y = (oy + (e.rawY - dy).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - dp(120)))
                        wm.updateViewLayout(strip, stripLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) { closeFlyout(); scroll.visibility = if (scroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
            }
            true
        }
        draw.tool = Tool.LASER
        refreshSel()
        setDrawing(false)
    }

    private fun toolName(t: Tool): String = when (t) {
        Tool.LASER -> "Laser"
        Tool.PEN -> "Pen"
        Tool.BRUSH -> "Brush"
        Tool.HIGHLIGHTER -> "Highlighter"
        Tool.ERASER -> "Eraser"
        else -> "Shapes"
    }

    private fun sectionFor(t: Tool): View = when (t) {
        Tool.LASER -> Ui.laser(this, tick)
        Tool.PEN -> Ui.pen(this, tick)
        Tool.BRUSH -> Ui.brush(this, tick)
        Tool.HIGHLIGHTER -> Ui.highlighter(this, tick)
        Tool.ERASER -> Ui.eraser(this, tick)
        else -> Ui.slider(this, "Stamp size", "stampSize", { "$it px" }, tick)
    }

    private fun tapTool(t: Tool, v: View) {
        val same = flyout != null && flyoutKey == t.name
        selectTool(t)
        if (same) closeFlyout() else openFlyout(t.name, toolName(t), sectionFor(t), v)
    }

    private fun tapShape(t: Tool, sym: String, v: View) {
        val again = armed && draw.tool == t && (t != Tool.STAMP || draw.stamp == sym)
        if (t == Tool.STAMP) draw.stamp = sym
        selectTool(t)
        if (again) {
            if (flyout != null && flyoutKey == "shapes") closeFlyout() else openFlyout("shapes", "Stamp size", sectionFor(Tool.STAMP), v)
        } else if (flyoutKey != "shapes") closeFlyout()
    }

    private fun selectTool(t: Tool) { draw.tool = t; setDrawing(true); refreshSel() }

    private fun refreshSel() {
        for ((t, v) in toolCells) v.background = Ui.pill(this, draw.tool == t)
        for ((tool, v) in shapeCells) v.background = Ui.pill(this, draw.tool == tool && (tool != Tool.STAMP || v.text.toString() == draw.stamp))
    }

    private fun openFlyout(key: String, title: String, content: View, anchor: View) {
        closeFlyout()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(12)) }
        val hd = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hd.addView(Ui.text(this, title, 14f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val xBtn = cell("✕", 14f)
        xBtn.setOnClickListener { closeFlyout() }
        hd.addView(xBtn, LinearLayout.LayoutParams(dp(32), dp(32)))
        col.addView(hd); col.addView(content)
        val box = MaxScroll(this, (dm.heightPixels * 0.7).toInt()).apply { addView(col); background = Ui.glass(this@OverlayService, 18, true) }
        val fw = minOf(dp(230), dm.widthPixels / 2)
        box.measure(View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val l = lp(fw, -2)
        l.gravity = Gravity.TOP or Gravity.START
        val rx = stripLp.x + stripW + dp(6)
        l.x = if (rx + fw > dm.widthPixels) maxOf(0, stripLp.x - fw - dp(6)) else rx
        l.y = loc[1].coerceIn(0, maxOf(0, dm.heightPixels - box.measuredHeight - dp(8)))
        blur(l)
        wm.addView(box, l)
        flyout = box; flyoutKey = key
    }

    private fun closeFlyout() {
        flyout?.let { runCatching { wm.removeView(it) } }
        flyout = null; flyoutKey = ""
    }

    private fun scheduleRelease() {
        handler.removeCallbacks(release)
        val s = P.i(this, "autoRelease")
        if (armed && s > 0) handler.postDelayed(release, s * 1000L)
    }

    // armed = true: the overlay catches touches so you can draw. false: touches go straight to the app underneath.
    private fun setDrawing(on: Boolean) {
        armed = on
        modeDraw.background = Ui.pill(this, on); modeTouch.background = Ui.pill(this, !on)
        drawLp.flags = if (on) drawLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(draw, drawLp)
        if (on) scheduleRelease() else handler.removeCallbacks(release)
    }

    private fun showUi(s: Boolean) {
        val v = if (s) View.VISIBLE else View.INVISIBLE
        stripView.visibility = v
        flyout?.visibility = v
    }

    private fun select(ai: Boolean) {
        showUi(false)
        val holder = arrayOfNulls<View>(1)
        val sv = SelectView(this, ai) { r ->
            holder[0]?.let { wm.removeView(it) }
            if (r == null) showUi(true) else begin(r, ai)
        }
        holder[0] = sv
        wm.addView(sv, lp(-1, -1))
    }

    private fun begin(r: Rect, ai: Boolean) {
        if (proj != null) { grab(r, ai); return }
        pending = r to ai
        startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "STOP" -> stopSelf()
            "DENIED" -> { pending = null; showUi(true); Toast.makeText(this, "Screen capture permission was declined", Toast.LENGTH_SHORT).show() }
            "PROJ" -> { @Suppress("DEPRECATION") val d = i!!.getParcelableExtra<Intent>("data"); if (d != null) startProj(i.getIntExtra("code", 0), d) }
        }
        return START_NOT_STICKY
    }

    private fun startProj(code: Int, data: Intent) {
        fg(true)
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { vd?.release(); reader?.close(); vd = null; reader = null; proj = null }
        }, handler)
        proj = p
        val w = dm.widthPixels; val h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay("ink", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        pending?.let { pd -> handler.postDelayed({ grab(pd.first, pd.second) }, 500) }; pending = null
    }

    private fun grab(r: Rect, ai: Boolean) {
        handler.postDelayed({
            val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                val pl = img.planes[0]
                val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(pl.buffer)
                lastFrame = Bitmap.createBitmap(full, 0, 0, img.width, img.height); img.close()
            }
            showUi(true)
            val f = lastFrame
            if (f == null) { Toast.makeText(this, "Capture failed, try again", Toast.LENGTH_SHORT).show(); return@postDelayed }
            val l = r.left.coerceIn(0, f.width - 2); val t = r.top.coerceIn(0, f.height - 2)
            val crop = Bitmap.createBitmap(f, l, t, minOf(r.width(), f.width - l), minOf(r.height(), f.height - t))
            if (ai) ask(crop) else save(crop)
        }, 400)
    }

    private fun save(b: Bitmap) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ScreenInk_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScreenInk")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        if (u != null) {
            contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Saved to Pictures/ScreenInk", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ask(crop: Bitmap) {
        answer?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply { text = "Thinking…"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(4), dp(8), dp(4), dp(8)) }
        val sc = MaxScroll(this, (dm.heightPixels * 0.4).toInt()).apply { addView(tv) }
        val thumb = ImageView(this).apply { setImageBitmap(crop); adjustViewBounds = true; maxHeight = dp(160) }
        fun chip(s: String) = TextView(this).apply { text = s; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = Ui.pill(this@OverlayService, false); setPadding(dp(16), dp(10), dp(16), dp(10)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = Ui.glass(this@OverlayService, 20, true); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        val copy = chip("📋 Copy").apply { setOnClickListener { getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ai", tv.text)) } }
        val close = chip("✖ Close").apply { setOnClickListener { runCatching { wm.removeView(box) }; answer = null } }
        bar.addView(copy); bar.addView(close, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        box.addView(TextView(this).apply { text = "✨ Gemini"; textSize = 14f; setTextColor(0xFFBFC3FF.toInt()) })
        box.addView(thumb); box.addView(sc); box.addView(bar)
        wm.addView(box, lp(minOf(dm.widthPixels - dp(32), dp(560)), -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(24) })
        answer = box
        val key = P.s(this, "apiKey").trim()
        if (key.isEmpty()) { tv.text = "Add your Gemini API key in the ScreenInk app (Ask AI section)."; return }
        val prompt = P.s(this, "prompt"); val model = P.s(this, "model").trim()
        Thread { val res = gemini(crop, prompt, key, model); handler.post { tv.text = res.replace("**", "").replace("\n* ", "\n• ") } }.start()
    }

    private fun gemini(b: Bitmap, prompt: String, key: String, model: String): String {
        return try {
            val s = minOf(1f, 1280f / maxOf(b.width, b.height))
            val sb = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
            val bo = ByteArrayOutputStream(); sb.compress(Bitmap.CompressFormat.JPEG, 85, bo)
            val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            val parts = JSONArray().put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code >= 400) "Error $code: " + runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            else JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Could not get an answer: ${e.message}" }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(release)
        for (v in listOf<View?>(draw, stripView, flyout, answer)) v?.let { runCatching { wm.removeView(it) } }
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
